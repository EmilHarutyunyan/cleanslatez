import AboutContact from './AboutContact';
export default AboutContact;