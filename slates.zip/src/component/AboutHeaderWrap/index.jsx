import AboutHeaderWrap from './AboutHeaderWrap';
export default AboutHeaderWrap;