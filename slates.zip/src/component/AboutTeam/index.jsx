import AboutTeam from './AboutTeam';
export default AboutTeam;