import BannerSection from './BannerSection';
export default BannerSection;