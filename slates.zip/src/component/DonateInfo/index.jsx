import DonateInfo from './DonateInfo';
export default DonateInfo;