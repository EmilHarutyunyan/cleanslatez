import FaqsAccordion from './FaqsAccordion';
export default FaqsAccordion;