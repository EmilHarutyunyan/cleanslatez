import MedicalDebt from './MedicalDebt';
export default MedicalDebt;