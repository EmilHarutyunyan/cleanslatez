import ProgramsPoint from './ProgramsPoint';
export default ProgramsPoint;