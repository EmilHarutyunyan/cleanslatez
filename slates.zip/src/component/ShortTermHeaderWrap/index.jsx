import ShortTermHeaderWrap from './ShortTermHeaderWrap';
export default ShortTermHeaderWrap;