import TensMillions from './TensMillions';
export default TensMillions;